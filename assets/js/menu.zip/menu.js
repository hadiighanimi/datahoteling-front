document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.querySelector(".mobile-nav-toggle");
    const body = document.querySelector("body");
  
    toggleBtn.addEventListener("click", function () {
      // باز و بسته کردن منو
      body.classList.toggle("mobile-nav-active");
  
      // تغییر آیکون (bi-list ↔ bi-x)
      this.classList.toggle("bi-list");
      this.classList.toggle("bi-x");
    });
  });
  